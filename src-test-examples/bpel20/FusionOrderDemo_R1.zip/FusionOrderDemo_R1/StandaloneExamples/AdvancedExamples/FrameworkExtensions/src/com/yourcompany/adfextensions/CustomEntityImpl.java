package com.yourcompany.adfextensions;

import oracle.jbo.server.EntityImpl;

/**
 * Custom ADF Framework Extension Class for Entity Rows
 * @author you
 */
public class CustomEntityImpl extends EntityImpl {
  // Add your custom code here or use the
  // Source | Override Methods... dialog to override
  // methods in the base class.
}
