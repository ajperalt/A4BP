package com.yourcompany.adfextensions;

import oracle.jbo.server.ViewObjectImpl;

/**
 * Custom ADF Framework Extension Class for View Object Components
 * @author you
 */
public class CustomViewObjectImpl extends ViewObjectImpl {
  // Add your custom code here or use the
  // Source | Override Methods... dialog to override
  // methods in the base class.
}
