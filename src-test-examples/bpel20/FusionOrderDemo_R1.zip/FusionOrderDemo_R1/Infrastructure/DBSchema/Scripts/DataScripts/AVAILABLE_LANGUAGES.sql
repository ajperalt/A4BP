REM Define the languages available on the system
REM $Id: AVAILABLE_LANGUAGES.sql 2096 2007-08-08 06:27:08Z csteriad $

insert into AVAILABLE_LANGUAGES values ('EN','Y',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('FR', 'N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('DE', 'N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('JA','N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('EL','N',0,SYSDATE,0,SYSDATE,1);
