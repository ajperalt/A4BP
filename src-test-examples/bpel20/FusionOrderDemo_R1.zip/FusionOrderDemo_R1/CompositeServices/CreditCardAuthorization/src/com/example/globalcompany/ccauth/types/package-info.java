@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.globalcompany.example.com/ns/CCAuthorizationService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.example.globalcompany.ccauth.types;
