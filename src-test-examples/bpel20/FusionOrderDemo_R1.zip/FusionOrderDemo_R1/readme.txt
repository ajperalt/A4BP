
About the Oracle Fusion Order Demo Application

Fusion Order Demo (FOD) is an end-to-end application sample developed by Fusion Middleware Product Management. The
purpose of the demo is to demonstrate common use cases in Fusion Middleware applications, including the integration
between different components of the Fusion technology stack, (ADF, BPEL, and WebCenter). The demo contains several
applications that make up various parts of functionality.

Note that there are two versions of the demo: One which includes the ADF and SOA components (named
FusionOrderDemo_R1.zip), and one which includes these components, as well as WebCenter functionality. 
The latter demo zip is available from the WebCenter page on OTN. 

About the Applications included in the Demo (organized by extracted directory name)

CompositeServices - WebLogicFusionOrderDemo.jws is a sample SOA application based on Oracle Mediator, BPEL Process,
Human Task, Business Rules, and Messaging Service. This application shows how to use Oracle SOA Suite to
integrate a number of applications into one cohesive ordering system. The accompanying developer's guide for this
module is Oracle� Fusion Middleware Developer's Guide for Oracle SOA Suite 11g (part number E10224-01).

Infrastructure - Infrastructure.jws contains the database schema information for the sample application. All
applications use the same schema, FOD. The accompanying Developer's Guide for this module is Oracle�
Fusion Middleware Fusion Developer's Guide for Oracle Application Development Framework 11g (part number B31974-03).

MasterPriceList - MasterPriceList.jws is a sample application that integrates with Microsoft Excel to demonstrate
the use of ADF Desktop Integration functionality. The accompanying Developer's Guide for this module is Oracle� Fusion
Middleware Fusion Developer's Guide for Oracle Application Development Framework 11g (part number B31974-03).

StandaloneExamples - This module contains several workspaces that demonstrate various features of the ADF Framework
that are not included in the Store Front scenario. The accompanying Developer's Guide for this module is Oracle�
Fusion Middleware Fusion Developer's Guide for Oracle Application Development Framework 11g (part number B31974-03).

StoreFrontModule - StoreFrontModule.jws is a sample web application based on Oracle ADF Business Components,
ADF Model data bindings and ADF Faces. The application follows an online shopping scenario and contains hook points
for integrating with the CompositeServices module. The accompanying Developer's Guide for this module is Oracle�
Fusion Middleware Fusion Developer's Guide for Oracle Application Development Framework 11g (part number B31974-03).


The sample application is provided for informational purposes only.


Release Notes:

You will see three warnings when compiling the StoreFrontService project. These warnings are expected and will not
affect the functionality of the demo.



Credits

Fusion Order Demo was created by:

Laura Akel
Susan Duncan
Duncan Mills
Lynn Munsinger
Frank Nimphius
Juan Ruiz
Clemens Utschig
Kundan Vyas


